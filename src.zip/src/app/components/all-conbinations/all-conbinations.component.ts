import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ApiService } from 'src/services/api.service';
import { DataServiceService } from 'src/services/data-service.service';

@Component({
  selector: 'app-all-conbinations',
  templateUrl: './all-conbinations.component.html',
  styleUrls: ['./all-conbinations.component.scss']
})
export class AllConbinationsComponent implements OnInit {
  constructor(private service: ApiService,private router: Router, private dataService:DataServiceService) { }
 allCombinations :[];


  ngOnInit(): void {
   this.getData();
  }
  
  back(){
    this.dataService.flag=true;
    this.router.navigate(['/combination',true]);
  }

  getData(){
    this.service.getAllAPI(environment.combinationPagingCount).subscribe((res)=>{
      this.allCombinations = res;
      this.dataService.last=res.slice(-1)[0];
    })
  }

  nextPage(){
  this.getData();
  }

}
