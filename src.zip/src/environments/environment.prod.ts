export const environment = {
  production: true,
  combinationPagingCount: 10,
};
